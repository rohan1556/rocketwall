package com.rocketwall.app

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var setBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0B1026"))
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply { text = "🚀"; textSize = 88f; gravity = Gravity.CENTER })
        root.addView(TextView(this).apply {
            text = "RocketWall"; textSize = 32f; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Any video, photo or GIF as your live wallpaper — original quality, untouched."
            textSize = 15f; setTextColor(Color.parseColor("#AAB2D5")); gravity = Gravity.CENTER
            setPadding(0, pad / 2, 0, pad)
        })
        val pick = Button(this).apply { text = "Choose video / photo / GIF"; setOnClickListener { pickFile() } }
        setBtn = Button(this).apply { text = "Set as live wallpaper"; isEnabled = false; setOnClickListener { applyWallpaper() } }
        status = TextView(this).apply {
            setTextColor(Color.parseColor("#AAB2D5")); gravity = Gravity.CENTER; setPadding(0, pad, 0, 0)
        }
        root.addView(pick); root.addView(setBtn); root.addView(status)
        setContentView(root)
        refreshStatus()
    }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("video/*", "image/*"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, 1)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data ?: return
        if (requestCode != 1 || resultCode != RESULT_OK) return
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        getSharedPreferences("rw", MODE_PRIVATE).edit().putString("uri", uri.toString()).apply()
        refreshStatus()
    }

    private fun refreshStatus() {
        val saved = getSharedPreferences("rw", MODE_PRIVATE).getString("uri", null)
        setBtn.isEnabled = saved != null
        status.text = if (saved == null) "Nothing selected yet" else "Selected: " + Uri.parse(saved).lastPathSegment
    }

    private fun applyWallpaper() {
        val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
            ComponentName(this, WallpaperEngineService::class.java)
        )
        startActivity(i)
    }
}
