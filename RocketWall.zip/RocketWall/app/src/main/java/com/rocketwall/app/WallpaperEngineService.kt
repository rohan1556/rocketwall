package com.rocketwall.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.Drawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder

class WallpaperEngineService : WallpaperService() {
    override fun onCreateEngine(): Engine = RocketEngine()

    inner class RocketEngine : Engine() {
        private var player: MediaPlayer? = null
        private var drawable: Drawable? = null
        private var loadedUri: String? = null
        private var visible = false
        private var holder: SurfaceHolder? = null
        private val handler = Handler(Looper.getMainLooper())
        private val pm by lazy { getSystemService(Context.POWER_SERVICE) as PowerManager }

        // Pauses/resumes immediately when Battery Saver is switched on or off.
        private val powerReceiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) { updatePlayback() }
        }

        // Animated GIFs redraw only when a new frame is due; photos draw exactly once.
        private val frameCallback = object : Drawable.Callback {
            override fun invalidateDrawable(who: Drawable) { drawImage() }
            override fun scheduleDrawable(who: Drawable, what: Runnable, t: Long) {
                handler.postAtTime(what, who, t)
            }
            override fun unscheduleDrawable(who: Drawable, what: Runnable) {
                handler.removeCallbacks(what, who)
            }
        }

        override fun onCreate(sh: SurfaceHolder) {
            super.onCreate(sh)
            registerReceiver(powerReceiver, IntentFilter(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED))
        }

        override fun onSurfaceCreated(h: SurfaceHolder) { holder = h; load() }
        override fun onSurfaceChanged(h: SurfaceHolder, f: Int, w: Int, ht: Int) { holder = h; drawImage() }
        override fun onSurfaceDestroyed(h: SurfaceHolder) { release(); holder = null }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            if (v && prefs().getString("uri", null) != loadedUri) load()
            updatePlayback()
        }

        override fun onDestroy() {
            try { unregisterReceiver(powerReceiver) } catch (_: Exception) {}
            release()
            super.onDestroy()
        }

        private fun prefs() = getSharedPreferences("rw", Context.MODE_PRIVATE)

        // Run only when the wallpaper is on screen AND Battery Saver is off.
        private fun updatePlayback() {
            val run = visible && !pm.isPowerSaveMode
            val p = player
            if (p != null) { if (run) { if (!p.isPlaying) p.start() } else if (p.isPlaying) p.pause() }
            (drawable as? AnimatedImageDrawable)?.let { if (run) it.start() else it.stop() }
            if (drawable != null) drawImage()   // still frame stays visible when paused
        }

        private fun release() {
            player?.release(); player = null
            (drawable as? AnimatedImageDrawable)?.let { it.stop(); it.callback = null }
            drawable = null
            loadedUri = null
        }

        private fun load() {
            release()
            val h = holder ?: return
            val saved = prefs().getString("uri", null) ?: return
            val uri = Uri.parse(saved)
            loadedUri = saved
            try {
                val mime = contentResolver.getType(uri) ?: ""
                if (mime.startsWith("video/")) {
                    // Original file played as-is: no re-encoding, no downscaling.
                    player = MediaPlayer().apply {
                        setDataSource(applicationContext, uri)
                        setSurface(h.surface)
                        setVideoScalingMode(MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING)
                        isLooping = true
                        setVolume(0f, 0f)
                        setOnPreparedListener { updatePlayback() }
                        prepareAsync()
                    }
                } else {
                    val d = ImageDecoder.decodeDrawable(ImageDecoder.createSource(contentResolver, uri))
                    drawable = d
                    if (d is AnimatedImageDrawable) {
                        d.callback = frameCallback
                        d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                    }
                    updatePlayback()
                }
            } catch (e: Exception) { e.printStackTrace() }
        }

        private fun drawImage() {
            val d = drawable ?: return
            val h = holder ?: return
            val c: Canvas = try { h.lockCanvas() } catch (e: Exception) { null } ?: return
            try {
                c.drawColor(Color.BLACK)
                val iw = d.intrinsicWidth.coerceAtLeast(1)
                val ih = d.intrinsicHeight.coerceAtLeast(1)
                val s = maxOf(c.width / iw.toFloat(), c.height / ih.toFloat())
                c.save()
                c.translate((c.width - iw * s) / 2f, (c.height - ih * s) / 2f)
                c.scale(s, s)
                d.setBounds(0, 0, iw, ih)
                d.draw(c)
                c.restore()
            } finally { h.unlockCanvasAndPost(c) }
        }
    }
}
